package com.herotoner.heroalarm.ui

import com.herotoner.heroalarm.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val SOUND_NAMES = listOf("كلاسيكي", "هادئ", "تصاعدي")
val SOUND_RES = listOf(R.raw.alarm_classic, R.raw.alarm_soft, R.raw.alarm_rise)

/** Calendar.DAY_OF_WEEK values in Arabic week order (Saturday first) with short labels. */
val DAYS = listOf(7 to "سبت", 1 to "أحد", 2 to "اثنين", 3 to "ثلاثاء", 4 to "أربعاء", 5 to "خميس", 6 to "جمعة")

fun dayBit(calendarDay: Int) = 1 shl (calendarDay - 1)

fun fmtTime(h: Int, m: Int): String {
    val period = if (h < 12) "صباحاً" else "مساءً"
    val h12 = if (h % 12 == 0) 12 else h % 12
    return String.format(Locale.US, "%d:%02d %s", h12, m, period)
}

fun fmtClock(millis: Long): String = fmtTime(
    SimpleDateFormat("H", Locale.US).format(Date(millis)).toInt(),
    SimpleDateFormat("m", Locale.US).format(Date(millis)).toInt()
)

fun fmtDate(millis: Long): String = SimpleDateFormat("EEEE d MMMM yyyy", Locale("ar")).format(Date(millis))

fun daysText(mask: Int): String = when {
    mask == 0 -> "مرة واحدة"
    mask == 127 -> "كل يوم"
    else -> DAYS.filter { (mask and dayBit(it.first)) != 0 }.joinToString("، ") { it.second }
}

fun remainingText(ms: Long): String {
    val totalMin = (ms / 60_000L).coerceAtLeast(0)
    val d = totalMin / 1440
    val h = (totalMin % 1440) / 60
    val m = totalMin % 60
    return buildList {
        if (d > 0) add("$d يوم")
        if (h > 0) add("$h ساعة")
        if (m > 0 || (d == 0L && h == 0L)) add("$m دقيقة")
    }.joinToString(" و ")
}
