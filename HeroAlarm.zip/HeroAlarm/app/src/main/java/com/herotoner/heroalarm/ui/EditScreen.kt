package com.herotoner.heroalarm.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.herotoner.heroalarm.data.Alarm
import java.util.Locale

@Composable
fun EditScreen(initial: Alarm?, onSave: (Alarm) -> Unit, onCancel: () -> Unit) {
    var hour by remember { mutableIntStateOf(initial?.hour ?: 7) }
    var minute by remember { mutableIntStateOf(initial?.minute ?: 0) }
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var desc by remember { mutableStateOf(initial?.description ?: "") }
    var mask by remember { mutableIntStateOf(initial?.daysMask ?: 0) }
    var sound by remember { mutableIntStateOf(initial?.soundIndex ?: 0) }
    var volume by remember { mutableIntStateOf(initial?.volume ?: 80) }
    var enabled by remember { mutableStateOf(initial?.enabled ?: true) }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { first.requestFocus() } }

    fun wrap(v: Int, max: Int) = ((v % max) + max) % max

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 56.dp, vertical = 28.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        Text(if (initial == null) "إضافة منبّه" else "تعديل المنبّه", color = Gold, fontSize = 34.sp, fontWeight = FontWeight.Bold)

        Label("الساعة (٢٤ ساعة)")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HeroButton("−", { hour = wrap(hour - 1, 24) }, Modifier.width(90.dp), fontSize = 30.sp, focusRequester = first)
            Text(String.format(Locale.US, "%02d", hour), color = TextMain, fontSize = 52.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(120.dp))
            HeroButton("+", { hour = wrap(hour + 1, 24) }, Modifier.width(90.dp), fontSize = 30.sp)
        }

        Label("الدقيقة")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HeroButton("−٥", { minute = wrap(minute - 5, 60) }, Modifier.width(90.dp), fontSize = 26.sp)
            HeroButton("−", { minute = wrap(minute - 1, 60) }, Modifier.width(90.dp), fontSize = 30.sp)
            Text(String.format(Locale.US, "%02d", minute), color = TextMain, fontSize = 52.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(120.dp))
            HeroButton("+", { minute = wrap(minute + 1, 60) }, Modifier.width(90.dp), fontSize = 30.sp)
            HeroButton("+٥", { minute = wrap(minute + 5, 60) }, Modifier.width(90.dp), fontSize = 26.sp)
        }

        Label("عنوان المنبّه")
        HeroField(title, { title = it.take(60) }, "مثال: الاستيقاظ للعمل")
        Label("الوصف")
        HeroField(desc, { desc = it.take(200) }, "اكتب وصفاً يظهر على شاشة التنبيه")

        Label("التكرار (بدون اختيار = مرة واحدة)")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DAYS.forEach { (day, name) ->
                val bit = dayBit(day)
                HeroButton(name, { mask = mask xor bit }, Modifier.weight(1f), selected = (mask and bit) != 0, fontSize = 18.sp)
            }
        }

        Label("صوت التنبيه")
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            SOUND_NAMES.forEachIndexed { i, n -> HeroButton(n, { sound = i }, selected = sound == i) }
        }

        Label("مستوى الصوت")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HeroButton("−", { volume = (volume - 10).coerceIn(10, 100) }, Modifier.width(90.dp), fontSize = 30.sp)
            Text("$volume%", color = TextMain, fontSize = 36.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(120.dp))
            HeroButton("+", { volume = (volume + 10).coerceIn(10, 100) }, Modifier.width(90.dp), fontSize = 30.sp)
        }

        HeroButton(if (enabled) "المنبّه مفعّل" else "المنبّه متوقف", { enabled = !enabled }, selected = enabled)

        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            HeroButton("حفظ", {
                onSave(
                    (initial ?: Alarm()).copy(
                        hour = hour.coerceIn(0, 23), minute = minute.coerceIn(0, 59),
                        title = title.trim().ifEmpty { "منبّه" }, description = desc.trim(),
                        daysMask = mask and 127, soundIndex = sound, volume = volume.coerceIn(10, 100),
                        enabled = enabled, lastFiredAt = 0,
                    )
                )
            }, Modifier.width(220.dp).height(72.dp), primary = true, fontSize = 26.sp)
            HeroButton("إلغاء", onCancel, Modifier.width(220.dp).height(72.dp), fontSize = 26.sp)
        }
    }
}

@Composable
private fun Label(text: String) = Text(text, color = TextDim, fontSize = 20.sp)

@Composable
private fun HeroField(value: String, onChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        placeholder = { Text(hint, color = TextDim, fontSize = 20.sp) },
        textStyle = androidx.compose.ui.text.TextStyle(color = TextMain, fontSize = 24.sp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Gold, unfocusedBorderColor = CardHi,
            focusedContainerColor = CardBg, unfocusedContainerColor = CardBg, cursorColor = Gold,
        ),
        modifier = Modifier.fillMaxWidth(),
    )
}
