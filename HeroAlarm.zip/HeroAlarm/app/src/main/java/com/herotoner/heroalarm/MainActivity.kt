package com.herotoner.heroalarm

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.herotoner.heroalarm.alarm.AlarmScheduler
import com.herotoner.heroalarm.alarm.AlarmService
import com.herotoner.heroalarm.data.Alarm
import com.herotoner.heroalarm.data.AppDatabase
import com.herotoner.heroalarm.data.TEST_ALARM_ID
import com.herotoner.heroalarm.ui.EditScreen
import com.herotoner.heroalarm.ui.HeroTheme
import com.herotoner.heroalarm.ui.HomeScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface Screen {
    object Home : Screen
    data class Edit(val alarm: Alarm?) : Screen
}

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    val alarms = dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        // Re-register alarms in case the system dropped them (e.g. force-stop).
        viewModelScope.launch(Dispatchers.IO) { runCatching { AlarmScheduler.restoreAll(app, markMissed = true) } }
    }

    fun save(a: Alarm) = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val id = if (a.id == 0L) dao.insert(a) else { dao.update(a); a.id }
            AlarmScheduler.scheduleAndStore(app, dao, a.copy(id = id))
        }
    }

    fun toggle(a: Alarm) = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            val n = a.copy(enabled = !a.enabled, lastFiredAt = 0)
            dao.update(n)
            AlarmScheduler.scheduleAndStore(app, dao, n)
        }
    }

    fun delete(a: Alarm) = viewModelScope.launch(Dispatchers.IO) {
        runCatching { AlarmScheduler.cancel(app, a.id); dao.delete(a.id) }
    }

    fun disableAll() = viewModelScope.launch(Dispatchers.IO) {
        runCatching {
            dao.getAll().forEach { AlarmScheduler.cancel(app, it.id) }
            dao.disableAll()
        }
    }

    fun test() {
        runCatching {
            ContextCompat.startForegroundService(
                app, Intent(app, AlarmService::class.java).putExtra(AlarmScheduler.EXTRA_ID, TEST_ALARM_ID)
            )
        }
    }
}

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* denial is tolerated */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            runCatching {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
        setContent {
            HeroTheme {
                val alarms by vm.alarms.collectAsState()
                var screen by remember { mutableStateOf<Screen>(Screen.Home) }
                BackHandler(enabled = screen is Screen.Edit) { screen = Screen.Home }
                Crossfade(targetState = screen, label = "screen") { s ->
                    when (s) {
                        is Screen.Home -> HomeScreen(
                            alarms = alarms,
                            onAdd = { screen = Screen.Edit(null) },
                            onEdit = { screen = Screen.Edit(it) },
                            onDelete = { vm.delete(it) },
                            onToggle = { vm.toggle(it) },
                            onDisableAll = { vm.disableAll() },
                            onTest = { vm.test() },
                        )
                        is Screen.Edit -> EditScreen(
                            initial = s.alarm,
                            onSave = { vm.save(it); screen = Screen.Home },
                            onCancel = { screen = Screen.Home },
                        )
                    }
                }
            }
        }
    }
}
