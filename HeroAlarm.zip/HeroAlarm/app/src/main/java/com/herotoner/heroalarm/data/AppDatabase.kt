package com.herotoner.heroalarm.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Alarm::class, AlarmLog::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): AlarmDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext, AppDatabase::class.java, "hero_alarm.db"
            ).build().also { instance = it }
        }
    }
}

/** Id used by the "test alarm" button; it is never stored in the database. */
const val TEST_ALARM_ID = -2L

object AlarmStore {
    suspend fun load(context: Context, id: Long): Alarm? =
        if (id == TEST_ALARM_ID) {
            Alarm(
                id = TEST_ALARM_ID, title = "تجربة التنبيه",
                description = "هذا اختبار لشاشة التنبيه والصوت", volume = 80,
            )
        } else AppDatabase.get(context).dao().get(id)
}
