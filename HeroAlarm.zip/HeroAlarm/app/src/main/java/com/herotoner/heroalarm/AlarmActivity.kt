package com.herotoner.heroalarm

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.herotoner.heroalarm.alarm.AlarmScheduler
import com.herotoner.heroalarm.alarm.AlarmService
import com.herotoner.heroalarm.data.Alarm
import com.herotoner.heroalarm.data.AlarmStore
import com.herotoner.heroalarm.ui.Bg
import com.herotoner.heroalarm.ui.Gold
import com.herotoner.heroalarm.ui.HeroButton
import com.herotoner.heroalarm.ui.HeroTheme
import com.herotoner.heroalarm.ui.TextDim
import com.herotoner.heroalarm.ui.TextMain
import com.herotoner.heroalarm.ui.fmtClock
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AlarmActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true); setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val id = intent.getLongExtra(AlarmScheduler.EXTRA_ID, -1L)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = stopAlarm()
        })
        setContent { HeroTheme { AlarmScreen(id, ::stopAlarm) } }

        // Close automatically once the service stops ringing (timeout or stop from notification).
        lifecycleScope.launch {
            var seen = false
            AlarmService.ringing.collect { r -> if (r) seen = true else if (seen) finish() }
        }
        lifecycleScope.launch { delay(6000); if (!AlarmService.ringing.value) finish() }
    }

    private fun stopAlarm() {
        runCatching { startService(Intent(this, AlarmService::class.java).setAction(AlarmService.ACTION_STOP)) }
        finish() // returns to whatever was on screen before (e.g. YouTube)
    }
}

@Composable
private fun AlarmScreen(id: Long, onStop: () -> Unit) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val alarm by produceState<Alarm?>(null, id) { value = runCatching { AlarmStore.load(ctx, id) }.getOrNull() }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val s by pulse.animateFloat(1f, 1.18f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "scale")
    val a by pulse.animateFloat(0.7f, 1f, infiniteRepeatable(tween(700), RepeatMode.Reverse), label = "alpha")

    Column(
        Modifier.fillMaxSize()
            .background(Brush.radialGradient(listOf(Color(0xFF1B2750), Bg)))
            .padding(48.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Image(
            painterResource(R.drawable.ic_bell), null,
            Modifier.size(110.dp).scale(s).alpha(a), colorFilter = ColorFilter.tint(Gold),
        )
        Spacer(Modifier.height(8.dp))
        Text(fmtClock(now), color = TextMain, fontSize = 96.sp, fontWeight = FontWeight.Bold)
        Text(alarm?.title ?: "", color = Gold, fontSize = 52.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        val d = alarm?.description.orEmpty()
        if (d.isNotBlank()) Text(d, color = TextDim, fontSize = 30.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(36.dp))
        HeroButton("إيقاف المنبّه", onStop, Modifier.width(520.dp).height(110.dp), selected = true, fontSize = 40.sp, focusRequester = focus)
    }
}
