"""Generates the three built-in alarm sounds (16-bit mono WAV). Run: python3 tools/gen_sounds.py"""
import math, struct, wave, os
SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "app/src/main/res/raw")

def tone(freq, dur, vol=0.8, fade=0.01):
    n = int(SR * dur); out = []
    for i in range(n):
        t = i / SR
        env = min(1.0, t / fade, (dur - t) / fade)
        out.append(vol * env * math.sin(2 * math.pi * freq * t))
    return out

def silence(dur): return [0.0] * int(SR * dur)

def save(name, samples):
    with wave.open(os.path.join(OUT, name), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, s)) * 32767)) for s in samples))

classic = []
for _ in range(2):
    for _ in range(4): classic += tone(1000, 0.12) + silence(0.08)
    classic += silence(0.5)
save("alarm_classic.wav", classic)

soft = []
for f in (523.25, 659.25, 783.99, 1046.5): soft += tone(f, 0.35, 0.6, 0.05)
soft += silence(1.0)
save("alarm_soft.wav", soft)

rise = []
for f in (600, 750, 900, 1100, 1350): rise += tone(f, 0.18) + silence(0.06)
rise += silence(0.7)
save("alarm_rise.wav", rise)
